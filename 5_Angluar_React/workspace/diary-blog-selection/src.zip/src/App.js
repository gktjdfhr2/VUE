/* eslint-disable */
import React from 'react';
import logo from './logo.svg';
import './App.css';
import { render } from '@testing-library/react';


function App() {
    return (
      <div>
          <p>안녕</p>
      </div>
    );
}

export default App;
